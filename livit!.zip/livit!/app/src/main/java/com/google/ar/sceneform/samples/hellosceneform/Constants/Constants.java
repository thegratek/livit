package com.google.ar.sceneform.samples.hellosceneform.Constants;

public class Constants {
    public static String STATE_UP = "state_up";
    public static String STATE_DOWN = "state_down";
    public static String STATE_CAMERA = "state_camera";
}
