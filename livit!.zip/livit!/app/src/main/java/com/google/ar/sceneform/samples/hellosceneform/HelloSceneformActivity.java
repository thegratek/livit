/*
 * Copyright 2018 Google LLC. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.ar.sceneform.samples.hellosceneform;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaActionSound;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialog;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.ar.core.Anchor;
import com.google.ar.core.Config;
import com.google.ar.core.HitResult;
import com.google.ar.core.Plane;
import com.google.ar.core.Session;
import com.google.ar.core.exceptions.UnavailableApkTooOldException;
import com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException;
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException;
import com.google.ar.core.exceptions.UnavailableSdkTooOldException;
import com.google.ar.sceneform.AnchorNode;
import com.google.ar.sceneform.ArSceneView;
import com.google.ar.sceneform.HitTestResult;
import com.google.ar.sceneform.Node;
import com.google.ar.sceneform.assets.RenderableSource;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.samples.hellosceneform.Constants.Constants;
import com.google.ar.sceneform.ux.ArFragment;
import com.google.ar.sceneform.ux.BaseArFragment;
import com.google.ar.sceneform.ux.TransformableNode;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * This is an example activity that uses the Sceneform UX package to make common AR tasks easier.
 */
public class HelloSceneformActivity extends AppCompatActivity {
  private static final String TAG = HelloSceneformActivity.class.getSimpleName();
  private static final double MIN_OPENGL_VERSION = 3.0;

  private ArFragment arFragment;
  private ModelRenderable andyRenderable;
  private ModelRenderable plutoRenderable;
  private Integer i = 0;
  private GridView androidGridView;
  List<TransformableNode> transformableNodeList;
  GestureDetector gestureDetector;
  String[] imageNames;
    Integer selectedImageIndex = -1;
    List<ModelRenderable> sfbRenderables;
    FloatingActionButton fab,fab2;
    boolean isBottomSheetOpened = false;
    BottomSheetBehavior bottomSheetBehavior;

  @Override
  @SuppressWarnings({"AndroidApiChecker", "FutureReturnValueIgnored"})
  // CompletableFuture requires api level 24
  // FutureReturnValueIgnored is not valid
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    if (!checkIsSupportedDeviceOrFinish(this)) {
      return;
    }

    setContentView(R.layout.activity_ux);


    imageNames = new String[]{
      "chair_a","chair_b","artist_drawing_table","basic_table","flat_file_no_legs","paper_towel"
    };

      sfbRenderables = new ArrayList<ModelRenderable>();

      arFragment = (ArFragment) getSupportFragmentManager().findFragmentById(R.id.ux_fragment);

      transformableNodeList = new ArrayList<TransformableNode>();

      // When you build a Renderable, Sceneform loads its resources in the background while returning
    // a CompletableFuture. Call thenAccept(), handle(), or check isDone() before calling get().
    ModelRenderable.builder()
            .setSource(this, Uri.parse(Environment.getExternalStorageDirectory() + "/andy.sfb"))
        .build()
        .thenAccept(renderable -> andyRenderable = renderable)
        .exceptionally(
            throwable -> {
              Toast toast =
                  Toast.makeText(this, "Unable to load andy renderable", Toast.LENGTH_LONG);
              toast.setGravity(Gravity.CENTER, 0, 0);
              toast.show();
              return null;
            });


      ModelRenderable.builder()
          .setSource(this, Uri.parse(Environment.getExternalStorageDirectory() + "/pluto1.sfb"))
//              .setSource(this,R.raw.pluto1)
          .build()
          .thenAccept(renderable -> plutoRenderable = renderable)
          .exceptionally(
                  throwable -> {
                      Toast toast =
                              Toast.makeText(this, "Unable to load andy renderable", Toast.LENGTH_LONG);
                      toast.setGravity(Gravity.CENTER, 0, 0);
                      toast.show();
                      return null;
                  });

      for(Integer i=0;i<imageNames.length;i++){
          ModelRenderable.builder()
                  .setSource(this, Uri.parse(getFile(imageNames[i],".sfb")))
//              .setSource(this,R.raw.pluto1)
                  .build()
                  .thenAccept(renderable -> {
                      sfbRenderables.add(renderable);
                  })
                  .exceptionally(
                          throwable -> {
                              Toast toast =
                                      Toast.makeText(this, "Unable to load andy renderable", Toast.LENGTH_LONG);
                              toast.setGravity(Gravity.CENTER, 0, 0);
                              toast.show();
                              return null;
                          });
      }

    arFragment.setOnTapArPlaneListener(
        (HitResult hitResult, Plane plane, MotionEvent motionEvent) -> {
            if(selectedImageIndex!=-1) {
//          if (andyRenderable == null) {
//              Toast.makeText(this, "Renderabale is null", Toast.LENGTH_SHORT).show();
//            return;
//          }

//            Toast.makeText(this, "Plane Type " + plane.getType() , Toast.LENGTH_SHORT).show();
          // Create the Anchor.
          Anchor anchor = hitResult.createAnchor();
          AnchorNode anchorNode = new AnchorNode(anchor);
          anchorNode.setParent(arFragment.getArSceneView().getScene());


          // Create the transformable andy and add it to the anchor.
          TransformableNode andy = new TransformableNode(arFragment.getTransformationSystem());
          andy.getScaleController().setMinScale(0.2f);
          andy.getScaleController().setMaxScale(1f);
          andy.setParent(anchorNode);

              andy.setRenderable(sfbRenderables.get(selectedImageIndex));
              selectedImageIndex = -1;
                andy.select();
          }
        });

      LinearLayout llBottomSheet = (LinearLayout) findViewById(R.id.bottom_sheet);
      bottomSheetBehavior = BottomSheetBehavior.from(llBottomSheet);
//      bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
      bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

// set the peek height
//      bottomSheetBehavior.setPeekHeight(150);
      bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
          @Override
          public void onStateChanged(@NonNull View bottomSheet, int newState) {
              if(newState == BottomSheetBehavior.STATE_COLLAPSED) {
//                  Toast.makeText(getApplicationContext(), "Collapsed", Toast.LENGTH_SHORT).show();
              }
              if(newState == BottomSheetBehavior.STATE_EXPANDED) {
//                  Toast.makeText(getApplicationContext(), "Expanded", Toast.LENGTH_SHORT).show();
              }
          }

          @Override
          public void onSlide(@NonNull View bottomSheet, float slideOffset) {

          }
      });

      androidGridView = (GridView) findViewById(R.id.gridview_android_example);
      androidGridView.setAdapter(new ImageAdapterGridView(this));

      androidGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
              selectedImageIndex = position;
              bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
              bottomSheetBehavior.setPeekHeight(150);
//              Toast.makeText(getApplicationContext(), "Selected", Toast.LENGTH_SHORT).show();
          }
      });

      ImageView arrowButton = (ImageView) findViewById(R.id.bottom_sheet_arrow);
      arrowButton.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              if(bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                  bottomSheetBehavior.setPeekHeight(300);
                  bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
//                  Toast.makeText(getApplicationContext(), "Height " + llBottomSheet.getHeight(), Toast.LENGTH_SHORT).show();
              }
              else{
                  bottomSheetBehavior.setPeekHeight(150);
                  bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
//                  Toast.makeText(getApplicationContext(), "Height " + llBottomSheet.getHeight(), Toast.LENGTH_SHORT).show();
              }
          }
      });

      fab = (FloatingActionButton) findViewById(R.id.fab);
      fab.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              captureScreenshot();
          }
      });
  }

    private void captureScreenshot() {
        final String filename = getFile("myArScreen_" + System.currentTimeMillis(),".png");
        MediaActionSound sound = new MediaActionSound();
        sound.play(MediaActionSound.SHUTTER_CLICK);
        ArSceneView view = arFragment.getArSceneView();

        // Create a bitmap the size of the scene view.
        final Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(),
                Bitmap.Config.ARGB_8888);

        // Create a handler thread to offload the processing of the image.
        final HandlerThread handlerThread = new HandlerThread("PixelCopier");
        handlerThread.start();
        // Make the request to copy.
        PixelCopy.request(view, bitmap, (copyResult) -> {
            if (copyResult == PixelCopy.SUCCESS) {
                try {
                    saveBitmapToDisk(bitmap, filename);
                } catch (IOException e) {
                    Toast toast = Toast.makeText(HelloSceneformActivity.this, e.toString(),
                            Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                Toast toast = Toast.makeText(HelloSceneformActivity.this,
                        " Screenshot Saved", Toast.LENGTH_LONG);
                toast.show();
            } else {
                Toast toast = Toast.makeText(HelloSceneformActivity.this,
                        "Failed to copyPixels: " + copyResult, Toast.LENGTH_LONG);
                toast.show();
            }
            handlerThread.quitSafely();
        }, new Handler(handlerThread.getLooper()));
    }

    private void saveBitmapToDisk(Bitmap bitmap, String filename) throws IOException {

        File out = new File(filename);
        if (!out.getParentFile().exists()) {
            out.getParentFile().mkdirs();
        }
        try (FileOutputStream outputStream = new FileOutputStream(filename);
             ByteArrayOutputStream outputData = new ByteArrayOutputStream()) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputData);
            outputData.writeTo(outputStream);
            outputStream.flush();
            outputStream.close();
        } catch (IOException ex) {
            throw new IOException("Failed to save bitmap to disk", ex);
        }
    }

  /**
   * Returns false and displays an error message if Sceneform can not run, true if Sceneform can run
   * on this device.
   *
   * <p>Sceneform requires Android N on the device as well as OpenGL 3.0 capabilities.
   *
   * <p>Finishes the activity if Sceneform can not run
   */
  public static boolean checkIsSupportedDeviceOrFinish(final Activity activity) {
    if (Build.VERSION.SDK_INT < VERSION_CODES.N) {
      Log.e(TAG, "Sceneform requires Android N or later");
      Toast.makeText(activity, "Sceneform requires Android N or later", Toast.LENGTH_LONG).show();
      activity.finish();
      return false;
    }
    String openGlVersionString =
        ((ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE))
            .getDeviceConfigurationInfo()
            .getGlEsVersion();
    if (Double.parseDouble(openGlVersionString) < MIN_OPENGL_VERSION) {
      Log.e(TAG, "Sceneform requires OpenGL ES 3.0 later");
      Toast.makeText(activity, "Sceneform requires OpenGL ES 3.0 or later", Toast.LENGTH_LONG)
          .show();
      activity.finish();
      return false;
    }
    return true;
  }


    public class ImageAdapterGridView extends BaseAdapter{

        private Context mContext;

        public ImageAdapterGridView(Context c) {
            mContext = c;
        }

        @Override
        public int getCount() {
            return imageNames.length;
        }

        @Override
        public Object getItem(int position) {
            return 0;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView mImageView;

            if (convertView == null) {
                mImageView = new ImageView(mContext);
                mImageView.setLayoutParams(new GridView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                mImageView = (ImageView) convertView;
            }
            File f = new File(getFile(imageNames[position],".png"));
            Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
            mImageView.setImageBitmap(bmp);
            return mImageView;
        }
    }

    private String getFile(String name, String extension){
      return Environment.getExternalStorageDirectory() + "/" + name + extension;
    }
}
